Metis Menu
--------------

Description of Metis Menu Copyright (c) 2014-2018 Osman Nuri Okumuş

We do not use a vanilla version of Metis Menu and our customisations are in the metismenu.js

For more information on this version of PHPMailer, check out https://github.com/onokumus/metismenu/releases/tag/v2.7.9

To upgrade this library:
1. Download the latest release of Metis Menu in https://github.com/onokumus/metismenu.
2. Remove the file amd/src/metismenu.js
3. Add a new amd/src/metismenu.js with the content of the file metisMenu.js
4. Run grunt amd command in the moodle root
5. Update lib/thirdpartylibs.xml.

Local changes (to verify/apply with new imports):
